# IndoSec-sHell
 Contact Us? facebook.com/IndoSecOfficial
 Contact Me? facebook.com/holiq.xid

Mau recode? Ijin dulu gan & no delete author
Asal recode? N00b kau:v
