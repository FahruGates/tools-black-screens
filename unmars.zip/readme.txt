====================== UNMARS [ Marshal Decompyler ] ======================
TUTORIAL :
1. buka marshal_code.py
2. Isi Marshal code
3. Save
4. Jalankan